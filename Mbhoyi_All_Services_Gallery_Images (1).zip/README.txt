MBHOYI ENTERPRISE — GALLERY ASSETS

Upload these WebP images into your GitHub repository assets folder.

The six *-illustrative.webp images are AI-generated visual examples, NOT photographs of completed Mbhoyi projects. Label them Illustrative / Design inspiration on your website. Replace with verified project photographs when available.

The two epoxy-colour-board files are adapted from the two boards supplied in this conversation and should be labelled Colour options, not completed installations.

Suggested paths: assets/tiling-illustrative.webp, assets/paving-illustrative.webp, assets/vinyl-illustrative.webp, assets/renovations-illustrative.webp, assets/general-building-illustrative.webp.

No website HTML was modified in this package.
